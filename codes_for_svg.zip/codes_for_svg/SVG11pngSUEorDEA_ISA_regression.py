# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import statsmodels.api as sm

plt.rcParams['font.family'] = "Arial"
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['svg.fonttype'] = 'none'

tim = "wn" ### sd or sn or wd or wn
file_path = fr"E:\data_analysis\UHI\statistics20260110\037SUHIFP_yearly_data\SUHI_FP_2005_2020_{tim}.csv"
save_path = fr"E:\data_analysis\UHI\Figure_pdf\ITA_DEA_SUE_slope_{tim}.svg"
try:
    df = pd.read_csv(file_path)
except FileNotFoundError:
    print(f"Error: file {file_path} not found")
    df = pd.DataFrame()

comparisons = [
    { "y_col": "ITA", "label": "ITA", "color": "#93be70", "marker": "o" },
    { "y_col": "DEA", "label": "DEA", "color": "#5d9cec", "marker": "s" },
    { "y_col": "SUE", "label": "SUE", "color": "#e35978", "marker": "^" }
]

x_col = 'ISA' 

fig, ax = plt.subplots(figsize=(12, 12))
max_val = 0 

for comp in comparisons:
    y_col = comp['y_col']
    if y_col not in df.columns or x_col not in df.columns: continue

    sub_df = df[[x_col, y_col]].dropna().sort_values(by=x_col)
    if len(sub_df) < 2: continue

    x_base = sub_df[x_col].iloc[0]
    y_base = sub_df[y_col].iloc[0]
    x_pct = (sub_df[x_col] - x_base) / x_base * 100
    y_pct = (sub_df[y_col] - y_base) / y_base * 100
    
    current_max = max(x_pct.max(), y_pct.max())
    if current_max > max_val: max_val = current_max

    X = sm.add_constant(x_pct)
    model = sm.OLS(y_pct, X).fit()
    slope = model.params[1]
    r2 = model.rsquared

    x_pred = np.linspace(0, x_pct.max(), 100)
    X_pred = sm.add_constant(x_pred)
    y_pred = model.predict(X_pred)
    
    ax.scatter(x_pct, y_pct, color=comp["color"], marker=comp["marker"], 
               s=80, alpha=0.75, edgecolors='white', linewidth=1.2)
    
    label_text = f"{comp['label']} Slope={slope:.3f}, $R^2$={r2:.2f}"
    ax.plot(x_pred, y_pred, color=comp["color"], linewidth=3, label=label_text)
    
    pred_summary = model.get_prediction(X_pred).summary_frame(alpha=0.10)
    ax.fill_between(x_pred, pred_summary['obs_ci_lower'], pred_summary['obs_ci_upper'], 
                    color=comp["color"], alpha=0.08)

limit = max_val + 10
ax.set_aspect('equal')
ax.set_xlim(-5, limit)
ax.set_ylim(-5, limit)

ax.plot([0, limit], [0, limit], ls='--', color='gray', alpha=0.5, linewidth=2)
text_pos = limit * 0.65

ax.set_xlabel(f"Urban area growth (%)", fontsize=44, fontweight='bold', labelpad=10)
ax.set_ylabel("SUHIF growth (%)", fontsize=44, fontweight='bold', labelpad=10)

ax.tick_params(which='major', direction='in', length=8, width=2, labelsize=36, pad=8)

for spine in ax.spines.values():
    spine.set_linewidth(2.0)

ax.grid(False) 

ax.legend(loc='upper left', frameon=False, fontsize=32, handlelength=1.5)

plt.tight_layout()
plt.savefig(save_path, format='svg', bbox_inches='tight', transparent=True)
plt.show()