# -*- coding: utf-8 -*-
import rasterio
from rasterio.warp import reproject, Resampling
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error
import matplotlib.pyplot as plt
from matplotlib import font_manager
from scipy import stats
from pyproj import Geod
import matplotlib.lines as mlines
from mpl_toolkits.axes_grid1 import make_axes_locatable
import matplotlib.colors as mcolors
from matplotlib.ticker import MultipleLocator

geod = Geod(ellps='WGS84')

plt.rcParams["font.family"] = "Arial"

### ITA "E:\\SUHI_FP\\stats20260110\\climate_zone\\global_summer_day_2018_Arid.tif"
### DEA "E:\\SUHI_FP\\stats20260110\\climate_zone\\SUHII_DEA_2018_sd_Arid.tif"
### SUE "E:\\SUHI_FP\\stats20260110\\climate_zone\\SUHII_SUE_2018_sd_Arid.tif"
climate_type = ["Tropical","Arid","Temperate","Cold"]
season_time = ['summer_night','sn']
### ['summer_night','sn'] ### ['summer_day','sd']
for i in climate_type:
    tif1_path = f"E:\\SUHI_FP\\stats20260110\\climate_zone\\SUHII_DEA_2018_{season_time[1]}_{i}.tif"
    ### f"E:\\SUHI_FP\\stats20260110\\climate_zone\\global_{season_time[0]}_2018_{i}.tif"
    ### f"E:\\SUHI_FP\\stats20260110\\climate_zone\\SUHII_DEA_2018_{season_time[1]}_{i}.tif"
    tif2_path = f"E:\\SUHI_FP\\stats20260110\\climate_zone\\SUHII_SUE_2018_{season_time[1]}_{i}.tif"
    ### f"E:\\SUHI_FP\\stats20260110\\climate_zone\\SUHII_DEA_2018_{season_time[1]}_{i}.tif"
    ### f"E:\\SUHI_FP\\stats20260110\\climate_zone\\SUHII_SUE_2018_{season_time[1]}_{i}.tif"
    save_png = fr"E:\data_analysis\UHI\Figure_pdf\comparison_summer\DEA_VS_SUE_{i}_{season_time[1]}.png"
    x_label = 'SUHII (°C)\n(DEA method)'
    y_label = 'SUHII (°C)\n(SUE method)'
    ### 'SUHII (°C)\n(DEA method)' 'SUHII (°C)\n(SUE method)'

    with rasterio.open(tif1_path) as src1:
        arr1 = src1.read(1)
        profile = src1.profile
        nodata1 = src1.nodata
        transform1 = src1.transform
        crs1 = src1.crs

    with rasterio.open(tif2_path) as src2:
        arr2 = src2.read(1)
        nodata2 = src2.nodata
        transform2 = src2.transform
        crs2 = src2.crs

    arr2_resampled = np.empty_like(arr1)
    reproject(
        source=arr2,
        destination=arr2_resampled,
        src_transform=transform2,
        src_crs=crs2,
        dst_transform=transform1,
        dst_crs=crs1,
        resampling=Resampling.bilinear
    )

    mask = (~np.isnan(arr1)) & (~np.isnan(arr2_resampled))

    if nodata1 is not None:
        mask &= (arr1 != nodata1)
    if nodata2 is not None:
        mask &= (arr2_resampled != nodata2)

    mask &= (arr1 > 0) & (arr2_resampled > 0)

    x_vals = arr1[mask].astype(np.float64) / 100.0
    y_vals = arr2_resampled[mask].astype(np.float64) / 100.0

    finite_mask = np.isfinite(x_vals) & np.isfinite(y_vals)
    x = x_vals[finite_mask].reshape(-1, 1)
    y = y_vals[finite_mask]

    if len(x) == 0:
        print("Error: After applying the >0 filter, no valid cells remain for analysis. Please check the data range.")
    else:
        print(f"Number of samples after cleaning: {len(x)}")
        print(f"x (ITA) Range: {np.min(x):.4f} ~ {np.max(x):.4f}")
        print(f"y (DEA) Range: {np.min(y):.4f} ~ {np.max(y):.4f}")

        model = LinearRegression()
        model.fit(x, y)
        y_pred = model.predict(x)

        r2 = model.score(x, y)
        rmse = np.sqrt(mean_squared_error(y, y_pred))
        mae = mean_absolute_error(y, y_pred)
        n_samples = len(x)

        print("-" * 30)
        print("Regression results (only containing regions > 0):")
        print(f"Equation: y = {model.coef_[0]:.4f} * x + {model.intercept_:.4f}")
        print(f"R²   = {r2:.4f}")
        print(f"RMSE = {rmse:.4f} °C")
        print(f"MAE  = {mae:.4f} °C")
        print(f"N    = {n_samples}")
        print("-" * 30)

    start_color_hex = '#fbdade'
    end_color_hex = '#f27f0b'

    start_color_rgb = mcolors.hex2color(start_color_hex)
    end_color_rgb = mcolors.hex2color(end_color_hex)

    colors = [start_color_rgb, end_color_rgb]
    custom_cmap = mcolors.LinearSegmentedColormap.from_list("my_custom_cmap", colors)

    custom_cmap.set_under(start_color_rgb)

    scale_factor = 1.5
    fontsize1 = 14 * 1.53
    fontsize2 = 12 * 1.53
    tick_fontsize = 12 * 1.53

    fig, ax = plt.subplots(figsize=(8, 8))

    ax.set_facecolor(start_color_hex)

    x_flat = x.flatten()
    min_val = min(np.min(x_flat), np.min(y))
    max_val = max(np.max(x_flat), np.max(y))

    padding = (max_val - min_val) * 0.05
    plot_min = min_val - padding
    plot_max = max_val + padding

    bin_size = 1.0
    num_bins = int(np.ceil((plot_max - plot_min) / bin_size))
    print(f"Calculated bin count for each axis: {num_bins}")

    hist, xedges, yedges, im = ax.hist2d(x_flat, y, bins=num_bins, cmap=custom_cmap)

    cbar_vmax = np.max(hist)
    norm = mcolors.Normalize(vmin=0, vmax=cbar_vmax)

    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.1)

    cax.tick_params(labelsize=tick_fontsize)  

    cbar = plt.colorbar(im, cax=cax, norm=norm, extend='min')
    cbar.set_label('Num of samples',
                fontsize=fontsize1,
                fontproperties=font_manager.FontProperties(family='Arial',
                                                            size=fontsize1), fontweight='bold')

    reference_line, = ax.plot([plot_min, plot_max], [plot_min, plot_max], color='#313652', linestyle='--', linewidth=2, label='y = x')

    x_plot_range = np.array([[plot_min], [plot_max]])
    y_plot_pred = model.predict(x_plot_range)
    if model.intercept_ > 0:
        regression_line, = ax.plot(x_plot_range, y_plot_pred, color='#5db7a4', linewidth=2, label='y = {:.2f}x + {:.2f}'.format(model.coef_[0], model.intercept_))
    else:
        regression_line, = ax.plot(x_plot_range, y_plot_pred, color='#5db7a4', linewidth=2, label='y = {:.2f}x - {:.2f}'.format(model.coef_[0], abs(model.intercept_)))

    ax.set_xlabel(x_label, fontsize=fontsize1, fontweight='bold')
    ax.set_ylabel(y_label, fontsize=fontsize1, fontweight='bold')

    ax.tick_params(axis='both', which='major', labelsize=tick_fontsize)

    tick_spacing = 5 
    ax.xaxis.set_major_locator(MultipleLocator(tick_spacing))
    ax.yaxis.set_major_locator(MultipleLocator(tick_spacing))

    ax.set_xlim(plot_min, plot_max)
    ax.set_ylim(plot_min, plot_max)

    ax.set_aspect('equal', adjustable='box')

    metrics_text = f'$R^2$ = {r2:.2f}, RMSE = {rmse:.2f}°C'

    ax.text(0.02, 0.79, metrics_text,
            transform=ax.transAxes,
            fontsize=fontsize2,  
            fontproperties=font_manager.FontProperties(family='Arial', size=fontsize2),
            ha='left', va='top') 

    handles = [regression_line, reference_line] 
    labels = [h.get_label() for h in handles]

    ax.legend(handles, labels, fontsize=fontsize2, prop=font_manager.FontProperties(family='Arial', size=fontsize2), frameon=False, loc='upper left')

    plt.tight_layout()
    plt.savefig(save_png, dpi=2400, format='png') # , transparent=True
    # plt.show()