#-*-coding:utf-8-*-
import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.size'] = 22
plt.rcParams['svg.fonttype'] = 'none'

LAT_BIN_SIZE = 1
LAT_MIN = -45
LAT_MAX = 65

season = ["summer","winter"]
shp_day = f"E:\\SUHI_FP\\stats20260110\\global_SUHII_{season[0]}_day_magnitude.shp"
shp_night = f"E:\\SUHI_FP\\stats20260110\\global_SUHII_{season[0]}_night_magnitude.shp"
save_svg = f'E:\\data_analysis\\UHI\\Figure_pdf\\SUHII_Latitude_{season[0].capitalize()}_Day_Night_Bold.svg'

uhi_field = 'UHI_mean'

def calc_lat_profile(shp_path, uhi_field, lat_min, lat_max, bin_size, scale=0.01):
    gdf = gpd.read_file(shp_path)
    latitudes = gdf.geometry.y
    uhi_values = gdf[uhi_field] * scale

    lat_bins = np.arange(lat_min, lat_max + bin_size, bin_size) 

    lat_labels = (lat_bins[:-1] + lat_bins[1:]) / 2

    mean_vals, std_vals = [], []
    for i in range(len(lat_bins) - 1):
        mask = (latitudes >= lat_bins[i]) & (latitudes < lat_bins[i + 1])
        vals = uhi_values[mask]
        vals = vals[~np.isnan(vals)]
        
        if len(vals) > 0:
            mean_vals.append(vals.mean())
            std_vals.append(vals.std())
        else:
            mean_vals.append(np.nan)
            std_vals.append(np.nan)

    return np.array(lat_labels), np.array(mean_vals), np.array(std_vals)

print(f"Calculating... Bin size: {LAT_BIN_SIZE}°, Range: {LAT_MIN} ~ {LAT_MAX}")
lat_labels, mean_day, std_day = calc_lat_profile(shp_day, uhi_field, LAT_MIN, LAT_MAX, LAT_BIN_SIZE)
_, mean_night, std_night = calc_lat_profile(shp_night, uhi_field, LAT_MIN, LAT_MAX, LAT_BIN_SIZE)

valid_mask = (~np.isnan(mean_day)) & (~np.isnan(mean_night))
mask = np.zeros_like(mean_day, dtype=bool)
mask[valid_mask] = mean_day[valid_mask] > mean_night[valid_mask]

lat_higher_day = lat_labels[mask]

if len(lat_higher_day) > 0:
    lat_ranges = []
    if len(lat_higher_day) > 0:
        start = lat_higher_day[0]
        for i in range(1, len(lat_higher_day)):
            if lat_higher_day[i] - lat_higher_day[i - 1] > LAT_BIN_SIZE * 1.01: 
                lat_ranges.append((start, lat_higher_day[i - 1] + LAT_BIN_SIZE/2))
                start = lat_higher_day[i]
        lat_ranges.append((start, lat_higher_day[-1] + LAT_BIN_SIZE/2))
    
    print("The latitude range of SUHII during the day is higher than that at night:")
    for r in lat_ranges:
        print(f"{r[0]-LAT_BIN_SIZE/2:.1f}° ~ {r[1]:.1f}°")
else:
    print("No latitude range has a daytime temperature higher than nighttime temperature.")

# ==============================Plotting============================= #
fig, ax = plt.subplots(figsize=(6, 8))
ax.tick_params(axis='both', labelsize=18)

def plot_clean(ax, x_data, y_data, std_data, color, label):
    mask = ~np.isnan(x_data)

    x_valid = x_data[mask]
    y_valid = y_data[mask]
    std_valid = std_data[mask]

    ax.plot(x_valid, y_valid, color=color, lw=2, label=label)

    ax.fill_betweenx(y_valid, x_valid - std_valid, x_valid + std_valid,
                     color=color, alpha=0.3, lw=0, label="_nolegend_")

plot_clean(ax, mean_day, lat_labels, std_day, '#e35978', 'Daytime')

plot_clean(ax, mean_night, lat_labels, std_night, '#3b8ec2', 'Nighttime')

candidates = np.concatenate([
    mean_day - std_day, 
    mean_day + std_day,
    mean_night - std_night, 
    mean_night + std_night
])
x_valid_values = candidates[~np.isnan(candidates)]

if len(x_valid_values) > 0:
    x_min = np.min(x_valid_values)
    x_max = np.max(x_valid_values)
    padding = (x_max - x_min) * 0.1
    if padding == 0: padding = 1.0 
    ax.set_xlim(x_min - padding, x_max + padding)
else:
    ax.set_xlim(-5, 5)

ax.xaxis.set_major_locator(ticker.MultipleLocator(1.0))

ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.1f'))

# ax.set_xlim(-0.5, 4.0)
ax.set_ylim(LAT_MIN, LAT_MAX)
target_yticks = np.arange(LAT_MIN, LAT_MAX + 1, 20) 
ax.set_yticks(target_yticks)

ylabels = []
for y in target_yticks:
    if y > 0:
        ylabels.append(f"{int(abs(y))}°N")
    elif y < 0:
        ylabels.append(f"{int(abs(y))}°S")
    else:
        ylabels.append("0°")
ax.set_yticklabels(ylabels)

ax.set_xlabel("SUHII (°C)", fontsize=24, fontweight='bold')
ax.set_ylabel("Latitude", fontsize=24, fontweight='bold')
ax.grid(False)
ax.legend(frameon=False, fontsize=20, loc='upper right')

for spine in ax.spines.values():
    spine.set_linewidth(2)
ax.tick_params(axis='both', width=2)

plt.tight_layout()
plt.savefig(save_svg, format='svg', bbox_inches='tight')
plt.show()