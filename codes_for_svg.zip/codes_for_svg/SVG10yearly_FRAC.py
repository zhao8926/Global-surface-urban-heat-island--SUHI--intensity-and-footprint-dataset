# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
from matplotlib import rcParams

file_path = r"E:\data_analysis\UHI\statistics20260110\030FRAC_SUHIFP+ISA.xlsx"
periods = ['sd', 'sn', 'wd', 'wn']
period = periods[0]
save_png = f"E:\\data_analysis\\UHI\\Figure_pdf\\FRAC_2005_2024_{period}_new.svg"
df = pd.read_excel(file_path)

df = df[df['czone'] != 0]

years = range(2005, 2025)
frac_cols = [f"FRAC{y}{period}" for y in years]
isa_cols = [f"ISA{y}" for y in years]

czone_mapping = {10: "Tropical", 11: "Arid", 12: "Temperate", 13: "Cold"}

for f_col, i_col in zip(frac_cols, isa_cols):
    df[f"Rel_{f_col}"] = (df[f_col] - df[i_col]) / df[i_col]

def mean_ci(series, confidence=0.95):
    series = series.dropna()
    n = len(series)
    if n == 0:
        return np.nan, np.nan, np.nan
    mean = series.mean()
    se = stats.sem(series)
    h = se * stats.t.ppf((1 + confidence) / 2., n - 1)
    return mean, mean - h, mean + h

results = []
rel_frac_cols = [f"Rel_FRAC{y}{period}" for y in years]

for year, col in zip(years, rel_frac_cols):
    for zone in df['czone'].unique():
        df_zone = df[df['czone'] == zone]
        mean, lower, upper = mean_ci(df_zone[col])
        results.append({
            "Zone": czone_mapping[zone],
            "Year": year,
            "Mean": mean,
            "Lower": lower,
            "Upper": upper
        })
    # ---- Global ----
    mean_g, lower_g, upper_g = mean_ci(df[col])
    results.append({
        "Zone": "Global",
        "Year": year,
        "Mean": mean_g,
        "Lower": lower_g,
        "Upper": upper_g
    })

results_df = pd.DataFrame(results)

plt.style.use("seaborn-v0_8-whitegrid")

scale = 2.07
rcParams["font.family"] = "Arial"
rcParams["font.size"] = 15 * scale
rcParams["axes.titlesize"] = 13 * scale
rcParams["axes.labelsize"] = 13 * scale
rcParams["xtick.labelsize"] = 11 * scale
rcParams["ytick.labelsize"] = 11 * scale
rcParams["legend.fontsize"] = 11 * scale
plt.rcParams['svg.fonttype'] = 'none'
rcParams["axes.labelweight"] = "bold"  

plt.figure(figsize=(12, 8))

colors = {
    "Global": "#c0e6fe",
    "Tropical": "#e86569",
    "Arid": "#fccb78",
    "Temperate": "#9ce3a6",
    "Cold": "#52a8da"
}

for zone in ["Global", "Tropical", "Arid", "Temperate", "Cold"]:
    sub = results_df[results_df["Zone"] == zone]
    plt.errorbar(
        sub["Year"],
        sub["Mean"],
        yerr=sub["Mean"] - sub["Lower"],
        fmt='o',
        capsize=3 * scale,
        markersize=5 * scale,
        elinewidth=1.5,
        linewidth=1.5,
        color=colors.get(zone, "gray"),
        ecolor=colors.get(zone, "gray"),
        alpha=1.0,
        label=zone
    )

plt.ylabel("Relative FRAC")
plt.xticks(range(2005, 2027, 5))
plt.xlim(2004, 2025)

plt.gca().yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x*100:.2f}%'))

ax = plt.gca()
ax.grid(False) 

for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(1.2)
    spine.set_color("black")

plt.legend(frameon=False, loc="best")

plt.tight_layout()
plt.savefig(save_png, format='svg', bbox_inches='tight', transparent=True)
plt.show()
