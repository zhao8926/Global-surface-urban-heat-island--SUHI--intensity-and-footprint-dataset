# -*- coding: utf-8 -*-
import geopandas as gpd
import numpy as np
import pymannkendall as mk
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FuncFormatter 
from matplotlib import rcParams

def to_superscript(n):
    sup_map = {'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','-':'⁻'}
    return ''.join(sup_map.get(ch, ch) for ch in str(n))

def analyze_and_plot_footprint(ax, shp_path, label, color):
    gdf = gpd.read_file(shp_path)
    years = np.arange(2005, 2025)
    fid_fields = [f"FP_{year}" for year in years]

    yearly_totals = np.array([gdf[f].sum(skipna=True) for f in fid_fields], dtype=float)

    # Mann-Kendall + Sen’s slope
    res = mk.original_test(yearly_totals)
    slope, p_value = res.slope, res.p

    intercept = np.mean(yearly_totals) - slope * np.mean(years)
    trend_line = slope * years + intercept

    std_err = np.std(yearly_totals - trend_line) / np.sqrt(len(years))
    ci_upper = trend_line + 1.96 * std_err
    ci_lower = trend_line - 1.96 * std_err

    ax.fill_between(years, ci_lower, ci_upper, color=color, alpha=0.15)
    ax.plot(years, yearly_totals, 'o', color=color, markersize=10, alpha=0.8)
    ax.plot(years, trend_line, '-', color=color, linewidth=2.5)

    print(f"--- {label} ---")
    print(f"Sen's slope: {slope:.2f} km²/yr, p = {p_value:.3f}, trend: {res.trend}\n")

    return {'slope': slope, 'p_value': p_value, 'label': label}

if __name__ == '__main__':
    rcParams["font.family"] = "Arial"
    rcParams["mathtext.fontset"] = "custom"
    rcParams["mathtext.rm"] = "Arial"
    rcParams["axes.linewidth"] = 1.2
    rcParams["axes.edgecolor"] = "black"
    plt.rcParams['svg.fonttype'] = 'none'

    FONT_SCALE = 1.53

    base_path = "E:\\SUHI_FP\\stats20260110\\"
    path_day = f"{base_path}footprint_point_summer_day_dayu0.shp"
    path_night = f"{base_path}footprint_point_summer_night_dayu0.shp"
    save_png = r'E:\data_analysis\UHI\Figure_pdf\SUHI_FP_slope_summer_enhanced.svg'

    fig, ax = plt.subplots(figsize=(12, 7)) 

    day_res = analyze_and_plot_footprint(ax, path_day, 'Daytime', '#e85c43')
    night_res = analyze_and_plot_footprint(ax, path_night, 'Nighttime', '#3368cc')

    ax.set_ylabel("SUHIF area (km²)", fontsize=20 * FONT_SCALE, fontweight='bold')
    ax.xaxis.set_major_locator(MultipleLocator(5))
    ax.tick_params(axis='x', labelsize=16 * FONT_SCALE)
    ax.tick_params(axis='y', labelsize=16 * FONT_SCALE)
    ax.grid(False)
    ax.set_facecolor('white')

    def format_p(p): return "P < 0.001" if p < 0.001 else f"P = {p:.3f}"
    
    label_day = f"Daytime: slope = {day_res['slope']/1e5:.2f}×10{to_superscript(5)} km²/yr***"
    label_night = f"Nighttime: slope = {night_res['slope']/1e4:.2f}×10{to_superscript(4)} km²/yr***"

    ax.plot([], [], 'o-', color='#e85c43', markersize=10, linewidth=2.5, label=label_day)
    ax.plot([], [], 'o-', color='#3368cc', markersize=10, linewidth=2.5, label=label_night)

    ax.legend(frameon=False, prop={'size': 16 * FONT_SCALE, 'weight': 'bold'}, loc='upper left')

    ax.yaxis.set_major_locator(MultipleLocator(1e6))

    def y_tick_formatter(x, pos):
        if x == 0:
            return "0"
        return f"{x/1e6:.0f}×10{to_superscript(6)}"

    ax.yaxis.set_major_formatter(FuncFormatter(y_tick_formatter))

    plt.tight_layout()
    plt.savefig(save_png, format='svg', bbox_inches='tight', transparent=True)
    plt.show()