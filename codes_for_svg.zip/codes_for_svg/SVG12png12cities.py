# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import MaxNLocator
from matplotlib.ticker import MultipleLocator

file_sd = r"E:\data_analysis\UHI\statistics20260110\038example_city_statistics_sd.xlsx"
file_sn = r"E:\data_analysis\UHI\statistics20260110\039example_city_statistics_sn.xlsx"
file_wd = r"E:\data_analysis\UHI\statistics20260110\040example_city_statistics_wd.xlsx"
file_wn = r"E:\data_analysis\UHI\statistics20260110\041example_city_statistics_wn.xlsx"

df_sd = pd.read_excel(file_sd)
df_sn = pd.read_excel(file_sn)
df_wd = pd.read_excel(file_wd)
df_wn = pd.read_excel(file_wn)

period_map = {
    'SD': 'Summer Day',
    'SN': 'Summer Night',
    'WD': 'Winter Day',
    'WN': 'Winter Night'
}

city_map = {
    '新加坡': 'Singapore', 'Rio_de_Janeiro': 'Rio de Janeiro', '巴拿马城': 'Panama City',
    '三亚': 'Sanya', 'Las_vegas': 'Las Vegas', '吉达': 'Jeddah',
    '上海': 'Shanghai', 'Pairs': 'Paris', '华盛顿': 'Washington',
    '东京': 'Tokyo', '波士顿': 'Boston', '莫斯科': 'Moscow'
}

methods = ['ITA', 'DEA', 'SUE']
plot_data = []

def process_df(df, period_code):
    for index, row in df.iterrows():
        city = row['city_name']
        city_en = city_map.get(city, city)
        
        for method in methods:
            mean_val = row[f'{method}_mean'] * 0.01
            std_val = row[f'{method}_std'] * 0.01
            
            plot_data.append({
                'City': city,
                'City_En': city_en,
                'Period': period_map[period_code],
                'Method': method,
                'Mean': mean_val,
                'Std': std_val
            })

process_df(df_sd, 'SD')
process_df(df_sn, 'SN')
process_df(df_wd, 'WD')
process_df(df_wn, 'WN')

df_plot = pd.DataFrame(plot_data)

plt.rcParams['font.family'] = 'Arial' ### 'Times New Roman' 
plt.rcParams['font.size'] = 30 
plt.rcParams['axes.unicode_minus'] = False 
plt.rcParams['svg.fonttype'] = 'none'

colors = ["#93be70", "#5d9cec", "#e35978"] 

cities_en = df_plot['City_En'].unique()
periods = ['Summer Day', 'Summer Night', 'Winter Day', 'Winter Night']
period_labels = ['SD', 'SN', 'WD', 'WN'] 

x = np.arange(len(periods))
width = 0.25

fig, axes = plt.subplots(4, 3, figsize=(20, 16), dpi=1200)
axes = axes.flatten()

legend_handles = []

for i, city in enumerate(cities_en):
    ax = axes[i]
    city_data = df_plot[df_plot['City_En'] == city]
    
    means = {}
    stds = {}
    
    for idx, method in enumerate(methods):
        method_data = city_data[city_data['Method'] == method]
        
        sorter = {p: k for k, p in enumerate(periods)}
        method_data = method_data.copy()
        method_data['p_sort'] = method_data['Period'].map(sorter)
        method_data = method_data.sort_values('p_sort')
        
        means[method] = method_data['Mean'].values
        stds[method] = method_data['Std'].values
        
        bar = ax.bar(x + (idx - 1) * width, means[method], width, 
                     yerr=stds[method], label=method, 
                     color=colors[idx], 
                     capsize=4, 
                     error_kw={'linewidth': 1.2, 'alpha': 0.6, 'ecolor': 'gray'},
                     edgecolor='white', linewidth=0.8, zorder=3)
        
        if i == 0:
            legend_handles.append(bar)

    ax.set_ylim(bottom=0) 
    
    ax.yaxis.set_major_locator(MultipleLocator(2))

    ax.text(0.5, 0.90, city, transform=ax.transAxes, 
            ha='center', va='top', fontsize=36, fontweight='bold',
            bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.7))
    
    ax.set_xticks(x)
    ax.set_xticklabels(period_labels, fontsize=26) 
    
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_linewidth(1.2)
    ax.spines['bottom'].set_linewidth(1.2)
    
    ax.grid(axis='y', linestyle='--', alpha=0.4, zorder=0)

    if i % 3 == 0:
        ax.set_ylabel('SUHII (°C)', fontsize=32, fontweight='bold')

fig.align_ylabels(axes[::3])

fig.legend(legend_handles, methods, loc='upper center', 
           bbox_to_anchor=(0.5, 0.96), ncol=3, frameon=False, fontsize=36)

plt.tight_layout(rect=[0, 0, 1, 0.93]) 

output_path = r'E:\data_analysis\UHI\Figure_pdf\Fig\city_statistics.svg'
# plt.savefig(output_path, dpi=1200, bbox_inches='tight')
plt.savefig(output_path, format='svg', bbox_inches='tight')
print(f"Saved: {output_path}")

plt.show()