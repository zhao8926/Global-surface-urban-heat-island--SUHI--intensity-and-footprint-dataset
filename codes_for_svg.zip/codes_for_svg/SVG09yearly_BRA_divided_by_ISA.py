# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
from matplotlib import rcParams

season = 'wn'
file_path = fr"E:\data_analysis\UHI\statistics20260110\ISA_{season}.xlsx"
save_png = fr"E:\data_analysis\UHI\Figure_pdf\yearly_BRA_divided_by_ISA_{season}.svg"
df = pd.read_excel(file_path)

years = list(range(2005, 2025))

def mean_ci95(series):
    data = series.dropna()
    mean = np.mean(data)
    sem = stats.sem(data) 
    ci = stats.t.interval(0.95, len(data)-1, loc=mean, scale=sem) if len(data) > 1 else (mean, mean)
    lower, upper = ci
    return mean, lower, upper

results = []

for year in years:
    col = f"ratio{season}{year}"
    mean, lower, upper = mean_ci95(df[col])
    results.append(["Global", year, mean, lower, upper])

zones = {10: "Tropical", 11: "Arid", 12: "Temperate", 13: "Cold"}

for zone_code, zone_name in zones.items():
    sub_df = df[df["czone"] == zone_code]
    for year in years:
        col = f"ratio{season}{year}"
        mean, lower, upper = mean_ci95(sub_df[col])
        results.append([zone_name, year, mean, lower, upper])

result_df = pd.DataFrame(results, columns=["Zone", "Year", "Mean", "Lower", "Upper"])

plt.style.use("seaborn-v0_8-whitegrid")

rcParams["font.family"] = "Arial"
plt.rcParams['svg.fonttype'] = 'none'
rcParams["font.size"] = 15 * 2.00
rcParams["axes.titlesize"] = 13 * 2.00
rcParams["axes.labelsize"] = 13 * 2.00
rcParams["xtick.labelsize"] = 11 * 2.00
rcParams["ytick.labelsize"] = 11 * 2.00
rcParams["legend.fontsize"] = 11 * 1.6

plt.figure(figsize=(8, 5))

colors = {
    "Global": "#c0e6fe",       
    "Tropical": "#e86569",
    "Arid": "#fccb78",
    "Temperate": "#9ce3a6",
    "Cold": "#52a8da"
}

for zone in result_df["Zone"].unique():
    sub = result_df[result_df["Zone"] == zone]
    plt.errorbar(
        sub["Year"],
        sub["Mean"],
        yerr=sub["Mean"] - sub["Lower"],
        fmt='o',
        capsize=4,
        markersize=8,
        elinewidth=1,
        linewidth=1.2,
        color=colors.get(zone, "gray"),
        ecolor=colors.get(zone, "gray"),
        alpha=0.8,
        label=zone
    )

# plt.xlabel("Year", fontsize=13)
plt.ylabel("Times of Urban Area", fontweight='bold')
plt.xticks(range(2005, 2027, 5))
plt.xlim(2004, 2025)

ax = plt.gca()
ax.grid(True, which='major', color="#383351", linewidth=0.6, alpha=0.3)

for spine in ax.spines.values():
    spine.set_visible(True)
    spine.set_linewidth(1.2)
    spine.set_color("black")

# legend
# plt.legend(frameon=False, loc="best")

plt.tight_layout()
plt.savefig(save_png, format='svg', bbox_inches='tight', transparent=True)
plt.show()