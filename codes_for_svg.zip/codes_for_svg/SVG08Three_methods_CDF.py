#-*-coding:utf-8-*-
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import rasterio
import matplotlib.ticker as mtick
from matplotlib.ticker import MaxNLocator

tim = ['winter_night', 'wn']
### ['summer_day', 'sd'] ### ['summer_night', 'sn'] ### ['winter_day', 'wd'] ### ['winter_night', 'wn']
matplotlib.rcParams['font.family'] = 'Arial'
plt.rcParams['svg.fonttype'] = 'none'

def load_and_prepare_raster(filepath):
    with rasterio.open(filepath) as src:
        data = src.read(1)
        nodata_value = src.nodata
        if nodata_value is not None:
            mask = (data != nodata_value) & (data > 0)
            prepared_data = data[mask].flatten() * 0.01
        else:
            prepared_data = data.flatten() * 0.01
    return prepared_data

season = tim[0].split("_")[0].capitalize()
file_path1 = f"E:\\gis_data\\SUHII_Terra_{season}\\global_{tim[0]}_2018.tif"
file_path2 = f"E:\\gis_data\\SUHII_DEA_or_SUE\\seasonal_data\\SUHII_DEA_2018_{tim[1]}.tif"
file_path3 = f"E:\\gis_data\\SUHII_DEA_or_SUE\\merged_data\\SUHII_SUE_2018_{tim[1]}.tif"

data1 = load_and_prepare_raster(file_path1)
data2 = load_and_prepare_raster(file_path2)
data3 = load_and_prepare_raster(file_path3)

datasets = [data1, data2, data3]
labels = ['ITA data', 'DEA data', 'SUE data']
colors = ['#fbbfcb', '#41ff24', '#3bc0fd'] # 粉、绿、蓝

fig, ax = plt.subplots(figsize=(10, 6))
fontsiz_1 = 27
fontsiz_2 = 22

for data, label, color in zip(datasets, labels, colors):
    x_cdf = np.sort(data)
    N = len(data)
    y_cdf = np.arange(1, N + 1) / N
    
    # ax.fill_between(x_cdf, y_cdf, color=color, alpha=0.15, zorder=1)
    ax.fill_between(x_cdf, y_cdf, color=color, alpha=0.15, zorder=1, rasterized=True)
    ax.plot(x_cdf, y_cdf, color=color, linewidth=2.0, alpha=0.7, label=label, zorder=2, rasterized=True)

    q1_value = np.percentile(data, 25)
    q3_value = np.percentile(data, 75)

    iqr_mask = (x_cdf >= q1_value) & (x_cdf <= q3_value)
    ax.plot(x_cdf[iqr_mask], y_cdf[iqr_mask], color=color, linewidth=4.5, alpha=1.0, zorder=3)

ax.spines['left'].set_position('zero')
ax.spines['bottom'].set_position('zero')
ax.yaxis.set_major_formatter(mtick.PercentFormatter(xmax=1.0, decimals=0))
ax.xaxis.set_major_locator(MaxNLocator(integer=True))

all_data = np.concatenate(datasets)
global_max_val = np.max(all_data)
ax.set_ylabel('Cumulative Probability', fontsize=fontsiz_1, fontweight='bold')
ax.set_ylim(0, 1)
ax.set_xlim(0, global_max_val)
ax.set_xlabel('SUHII(°C)', fontsize=fontsiz_1, fontweight='bold')
ax.tick_params(axis='both', which='major', labelsize=fontsiz_2, direction = 'in')
ax.legend(fontsize=fontsiz_2, frameon=False, loc='lower right')

ax.axhline(0.5, color='grey', linestyle=':', linewidth=1.5, zorder=0)

ax.axhline(0.25, color='grey', linestyle=':', linewidth=1, alpha=0.7, zorder=0)
ax.axhline(0.75, color='grey', linestyle=':', linewidth=1, alpha=0.7, zorder=0)


plt.tight_layout()

plt.savefig(
       fr'E:\data_analysis\UHI\Figure_pdf\urban_heat_island_CDF_{tim[1]}.svg', 
       bbox_inches='tight', 
       facecolor='white',
       edgecolor='none',
       transparent=False,
       dpi=600
   )
plt.show()