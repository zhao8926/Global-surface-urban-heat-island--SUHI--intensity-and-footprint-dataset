# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
from matplotlib.ticker import ScalarFormatter
from matplotlib.ticker import FuncFormatter

file_ISA = r"E:\data_analysis\UHI\statistics20260110\036Area_ISA.csv"
file_BRA = r"E:\data_analysis\UHI\statistics20260110\001FP_area_summer_day.csv"
save_png = r"E:\data_analysis\UHI\Figure_pdf\new_SUHI_FP_ISA_by_climate_zone_sd.svg"

df_ISA = pd.read_csv(file_ISA)
df_BRA = pd.read_csv(file_BRA)

czones_keep = [10, 11, 12, 13]
df_ISA = df_ISA[df_ISA["czone"].isin(czones_keep)]

czone_col_map = {
    10: "Tropical",
    11: "Arid",
    12: "Temperate",
    13: "Cold"
}

years = list(range(2005, 2024 + 1))

records = []

for year in years:
    col_ISA = f"ISA{year}"

    if col_ISA not in df_ISA.columns:
        continue
    
    year_col_name = 'Year' if 'Year' in df_BRA.columns else 'year'
    if year not in df_BRA[year_col_name].values:
        continue

    for cz in czones_keep:
        ISA_sum = df_ISA[df_ISA["czone"] == cz][col_ISA].sum()

        row = df_BRA[df_BRA[year_col_name] == year]
        
        target_col = czone_col_map[cz]
        
        if not row.empty and target_col in df_BRA.columns:
            BRA_sum = row[target_col].values[0]
        else:
            BRA_sum = np.nan

        records.append({
            "year": year,
            "czone": cz,
            "ISA_sum": ISA_sum,
            "BRA_sum": BRA_sum
        })

df_long = pd.DataFrame(records)
df_long = df_long.dropna()

colors = {
    10: "#e86569",
    11: "#fccb78",
    12: "#9ce3a6",
    13: "#52a8da"
}

def format_sci(x, pos=None):
    if x == 0:
        return "0"
    exponent = int(np.floor(np.log10(abs(x))))
    coeff = x / 10**exponent
    return f"${coeff:.1f}\\times10^{{{exponent}}}$"

plt.rcParams["font.family"] = "Arial"
plt.rcParams["mathtext.fontset"] = "stix"
plt.rcParams["font.size"] = plt.rcParams["font.size"] * 2.0
plt.rcParams['svg.fonttype'] = 'none'

fig, ax = plt.subplots(figsize=(9, 7))

for cz in czones_keep:
    df_z = df_long[df_long['czone'] == cz].sort_values('year')
    x = df_z['ISA_sum'].values
    y = df_z['BRA_sum'].values

    X = sm.add_constant(x)
    model = sm.OLS(y, X).fit()
    xp = np.linspace(x.min(), x.max(), 200)
    Xp = sm.add_constant(xp)
    pred = model.get_prediction(Xp)
    pred_df = pred.summary_frame(alpha=0.05)

    ax.scatter(x, y, label=czone_col_map[cz], color=colors[cz], s=40, alpha=0.8)
    ax.plot(xp, pred_df['mean'], color=colors[cz], lw=2)
    ax.fill_between(xp, pred_df['mean_ci_lower'], pred_df['mean_ci_upper'], alpha=0.18, color=colors[cz])

    r2 = model.rsquared
    p = model.pvalues[1]
    p_text = "P < 0.001" if p < 0.001 else f"P = {p:.3f}"
    print(f"{czone_col_map[cz]}: R^2 = {r2:.3f}, {p_text}")

ax.set_xlabel("Urban area (km²)", fontweight='bold', fontsize=25)
ax.set_ylabel("SUHIF area (km²)", fontweight='bold', fontsize=25)

ax.legend(frameon=False, fontsize=plt.rcParams["font.size"] * 1.1)

ax.grid(False)

ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

ax.xaxis.set_major_formatter(ScalarFormatter(useMathText=True))
ax.yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
ax.ticklabel_format(style='sci', axis='both', scilimits=(0,0))

ax.xaxis.set_major_formatter(FuncFormatter(format_sci))
ax.yaxis.set_major_formatter(FuncFormatter(format_sci))

plt.tight_layout()
plt.savefig(save_png, format='svg', bbox_inches='tight', transparent=True)
plt.show()