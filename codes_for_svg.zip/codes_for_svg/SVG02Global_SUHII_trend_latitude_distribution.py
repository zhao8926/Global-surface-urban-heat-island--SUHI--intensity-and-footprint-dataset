#-*-coding:utf-8-*-
import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

plt.rcParams['font.family'] = 'Arial'
plt.rcParams['svg.fonttype'] = 'none'


LAT_BIN_SIZE = 1.0
LAT_MIN = -45
LAT_MAX = 65

season = ["summer","winter"]
season = season[1]
shp_day = f"E:\\SUHI_FP\\stats20260110\\global_SUHII_{season}_day_dayu0.shp"
shp_night = f"E:\\SUHI_FP\\stats20260110\\global_SUHII_{season}_night_dayu0.shp"
save_svg = f'E:\\data_analysis\\UHI\\Figure_pdf\\Trend_Latitude_{season.capitalize()}_Day_Night.svg'
uhi_field = 'slope_deca' ### 'UHI_mean' ### 'slope_deca'

def calc_lat_profile(shp_path, uhi_field, lat_min, lat_max, bin_size, scale=0.01):
    gdf = gpd.read_file(shp_path)
    latitudes = gdf.geometry.y
    uhi_values = gdf[uhi_field] * scale

    lat_bins = np.arange(lat_min, lat_max + bin_size, bin_size) 

    lat_labels = (lat_bins[:-1] + lat_bins[1:]) / 2

    mean_vals, std_vals = [], []
    for i in range(len(lat_bins) - 1):
        mask = (latitudes >= lat_bins[i]) & (latitudes < lat_bins[i + 1])
        vals = uhi_values[mask]
        vals = vals[~np.isnan(vals)]
        
        if len(vals) > 0:
            mean_vals.append(vals.mean())
            std_vals.append(vals.std())
        else:
            mean_vals.append(np.nan)
            std_vals.append(np.nan)

    return np.array(lat_labels), np.array(mean_vals), np.array(std_vals)

### Main Process

print(f"Calculating... Bin size: {LAT_BIN_SIZE}°, Range: {LAT_MIN} ~ {LAT_MAX}")
lat_labels, mean_day, std_day = calc_lat_profile(shp_day, uhi_field, LAT_MIN, LAT_MAX, LAT_BIN_SIZE)
_, mean_night, std_night = calc_lat_profile(shp_night, uhi_field, LAT_MIN, LAT_MAX, LAT_BIN_SIZE)

valid_mask = (~np.isnan(mean_day)) & (~np.isnan(mean_night))
mask = np.zeros_like(mean_day, dtype=bool)
mask[valid_mask] = mean_day[valid_mask] > mean_night[valid_mask]

lat_higher_day = lat_labels[mask]

if len(lat_higher_day) > 0:
    lat_ranges = []
    if len(lat_higher_day) > 0:
        start = lat_higher_day[0]
        for i in range(1, len(lat_higher_day)):
            if lat_higher_day[i] - lat_higher_day[i - 1] > LAT_BIN_SIZE * 1.01: 
                lat_ranges.append((start, lat_higher_day[i - 1] + LAT_BIN_SIZE/2))
                start = lat_higher_day[i]
        lat_ranges.append((start, lat_higher_day[-1] + LAT_BIN_SIZE/2))
    
    print("The latitude range of SUHII during the day is higher than that at night:")
    for r in lat_ranges:
        print(f"{r[0]-LAT_BIN_SIZE/2:.1f}° ~ {r[1]:.1f}°")
else:
    print("No latitude range has a daytime temperature higher than nighttime temperature.")

### Plotting
fig, ax = plt.subplots(figsize=(6, 8))
ax.tick_params(axis='both', labelsize=30)

ax.plot(mean_day, lat_labels, color='#e35978', lw=2, label='Daytime')
ax.fill_betweenx(lat_labels, mean_day - std_day, mean_day + std_day,
                 color='#efb8cc', alpha=0.5, label="_nolegend_")

ax.plot(mean_night, lat_labels, color='#3b8ec2', lw=2, label='Nighttime')
ax.fill_betweenx(lat_labels, mean_night - std_night, mean_night + std_night,
                 color='#b6d4ec', alpha=0.5, label="_nolegend_")

candidates = np.concatenate([
    mean_day - std_day, 
    mean_day + std_day,
    mean_night - std_night, 
    mean_night + std_night
])

x_valid_values = candidates[~np.isnan(candidates)]

if len(x_valid_values) > 0:
    x_min = np.min(x_valid_values)
    x_max = np.max(x_valid_values)

    x_min = min(x_min, 0)
    x_max = max(x_max, 0)

    padding = (x_max - x_min) * 0.1
    if padding == 0: padding = 1.0 
    
    ax.set_xlim(x_min - padding, x_max + padding)
else:
    ax.set_xlim(-5, 5)

ax.axvline(0, color='#3657a1', linestyle='--', linewidth=1.5)

ax.xaxis.set_major_locator(ticker.MultipleLocator(0.2)) 

ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.1f'))

ax.set_ylim(LAT_MIN, LAT_MAX)

target_yticks = np.arange(LAT_MIN, LAT_MAX + 1, 20) 
ax.set_yticks(target_yticks)

ylabels = []
for y in target_yticks:
    if y > 0:
        ylabels.append(f"{int(abs(y))}°N")
    elif y < 0:
        ylabels.append(f"{int(abs(y))}°S")
    else:
        ylabels.append("0°")
ax.set_yticklabels(ylabels)

ax.set_xlabel("Trend (°C/decade)", fontsize=36, fontweight='bold')
ax.set_ylabel("Latitude", fontsize=36, fontweight='bold')

ax.grid(False)

# legend
# ax.legend(frameon=False, fontsize=20, loc='upper right')

for spine in ax.spines.values():
    spine.set_linewidth(2)
ax.tick_params(axis='both', width=2)

plt.tight_layout()
plt.savefig(save_svg, format='svg', bbox_inches='tight')
plt.show()